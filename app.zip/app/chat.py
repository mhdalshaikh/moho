from __future__ import annotations

import re
from typing import Dict, Any, List, Tuple

from .retriever import hybrid_retrieve, citations
from .llm import chat_llm
from .tools import (

    to_chart,
    load_full_tables_from_hits,

)

def _collect_tables(retrieved: List[Tuple[str, dict, float]]):
    """
    Prefer loading full sheets (Parquet) via metadata pointers written at ingest time.
    Falls back to the 10-row preview text only if necessary.
    Returns list[(df, meta)].
    """
    return load_full_tables_from_hits(retrieved)

from .config import DF_REQUIRED
from . import tools as T  # for answer_with_df_or_explain and other helpers

def answer_query(query: str) -> Dict[str, Any]:
    hits = hybrid_retrieve(query)
    if not hits:
        return {"text": "I don't know (no evidence).", "confidence": 0.0, "citations": ""}

    cits = citations(hits)
    conf = sum(s for *_, s in hits) / max(len(hits), 1)

    # ---------- DF-first (single call) ----------
    df_ans = T.answer_with_df(query, hits)
    if df_ans:
        ans_text, telemetry = df_ans
        resp = {
            "text": f"{ans_text}\n\nSources: {cits}",
            "confidence": conf,
            "citations": cits,
            "meta": {"source": "dataframe", **(telemetry or {})},
        }
        # Attach chart if DF path produced one
        chart_html = (telemetry or {}).get("chart_html")
        if chart_html:
            resp["chart_html"] = chart_html
        return resp

    # ---------- Chart intent (for non-DF paths) ----------
    ql = (query or "").lower()
    wants_chart = any(k in ql for k in ("chart", "plot", "graph", "line", "bar", "column", "pie", "trend"))

    tabs = T.load_full_tables_from_hits(hits)
    chart_html = None
    if wants_chart and tabs:
        try:
            tables_for_chart = T.select_tables_for_query(query, tabs)
        except Exception:
            tables_for_chart = tabs
        try:
            chart_html = T.to_chart(query, tables_for_chart)
        except Exception:
            chart_html = None

    # ---------- DF-required policy ----------
    if DF_REQUIRED:
        resp = {
            "text": ("I didn’t find any tables to compute from.\n"
                     "Upload or reference a sheet, or ask a non-tabular question."),
            "confidence": conf,
            "citations": cits,
            "meta": {"source": "policy", "reason": "DF_REQUIRED_no_tables"},
        }
        if chart_html:
            resp["chart_html"] = chart_html
        return resp

    # ---------- Legacy numeric fallbacks ----------
    looked = lookup_net_sales(query, tabs)
    if looked is not None:
        note, df = looked
        resp = {
            "text": f"{note}\n\n```\n{df.to_string(index=False)}\n```\n\nSources: {cits}",
            "confidence": conf,
            "citations": cits,
        }
        if chart_html:
            resp["chart_html"] = chart_html
        return resp

    agg = aggregate(query, tabs)
    if agg is not None:
        note, df = agg
        resp = {
            "text": f"{note}\n\n```\n{df.to_string(index=False)}\n```\n\nSources: {cits}",
            "confidence": conf,
            "citations": cits,
        }
        if chart_html:
            resp["chart_html"] = chart_html
        return resp

    # ---------- LLM fallback ----------
    ctx = []
    for i, (t, m, _) in enumerate(hits, 1):
        ctx.append(f"[Source {i}: {m.get('source','?')}]\n{t}")

    prompt = f"Question: {query}\n\nUse ONLY these sources.\n\n" + "\n\n".join(ctx)
    out = chat_llm([{"role": "user", "content": prompt}])
    out = re.sub(r"\n{3,}", "\n\n", out).strip()

    res = {
        "text": f"{out}\n\nSources: {cits}",
        "confidence": conf,
        "citations": cits,
    }
    if chart_html:
        res["chart_html"] = chart_html
    return res
