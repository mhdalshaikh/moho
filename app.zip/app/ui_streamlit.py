# app/ui_streamlit.py
import os, sys
from typing import Any, Dict, Iterable

import streamlit as st

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from app.config import APP_TITLE
from app.ingest import ingest_docs
from app.chat import answer_query


# ---------------- UI helpers ----------------
def _coerce_html(html_like: Any) -> str:
    """Return a str HTML from either a str or a BytesIO-like object."""
    if isinstance(html_like, str):
        return html_like
    if hasattr(html_like, "getvalue"):
        try:
            return html_like.getvalue().decode("utf-8", "ignore")
        except Exception:
            return str(html_like)
    return str(html_like)


def _clean_text_if_chart(text: str | None, chart_html: str | None) -> str:
    """
    If the model returned a chart *and* a boilerplate 'no tables' message,
    suppress that message so we don't show a contradictory banner above a chart.
    """
    if not text:
        return ""
    if chart_html:
        t = text.strip().lower()
        if t.startswith("i didn’t find any tables") or t.startswith("i didn't find any tables"):
            return ""  # hide misleading banner
    return text


def _render_sources(sources: Iterable[str] | None):
    if not sources:
        return
    with st.container():
        st.markdown(
            "<div style='margin-top:.5rem; opacity:.7'>Sources:</div>",
            unsafe_allow_html=True,
        )
        cols = st.columns(min(len(sources), 6) or 1)
        for i, s in enumerate(sources):
            with cols[i % len(cols)]:
                st.caption(f"• {s}")


def _render_message(role: str, payload: Any):
    """Render a chat message payload (str or dict)."""
    with st.chat_message(role):
        if isinstance(payload, dict):
            text = payload.get("text", "")
            chart_html = payload.get("chart_html")
            text = _clean_text_if_chart(text, chart_html)
            if text:
                st.markdown(text)

            if chart_html:
                html = _coerce_html(chart_html)
                # A bit taller by default; let Streamlit handle the scroll
                st.components.v1.html(html, height=540, scrolling=True)

            _render_sources(payload.get("sources"))
        else:
            st.markdown(str(payload))


# ---------------- Page ----------------
st.set_page_config(page_title=APP_TITLE, page_icon="🦙", layout="wide")
st.title(APP_TITLE)

with st.sidebar:
    st.header("⚙️ Controls")
    if st.button("Re-index documents", use_container_width=True):
        with st.spinner("Indexing…"):
            try:
                ingest_docs()
                st.success("Done.")
            except Exception as e:
                st.error(f"Indexing failed: {e}")
    if st.button("Clear chat", use_container_width=True):
        st.session_state.pop("history", None)
        st.experimental_rerun()
    st.caption("Put PDFs/DOCX/TXT/CSV/XLSX into the `docs/` folder, then click Re-index.")

if "history" not in st.session_state:
    st.session_state.history = []  # list[(role, payload)]

# History
for role, content in st.session_state.history:
    _render_message(role, content)

# New input
q = st.chat_input("Ask about your documents… ")
if q:
    _render_message("user", q)

    with st.spinner("Thinking…"):
        out: Dict[str, Any] = answer_query(q)

    # Persist
    st.session_state.history.append(("user", q))
    st.session_state.history.append(("assistant", out))

    # Render assistant turn
    _render_message("assistant", out)

    # Confidence footer (if present)
    conf = out.get("confidence")
    if isinstance(conf, (int, float)):
        st.caption(f"Confidence ≈ {conf:.2f}")
