# app/tools.py
from __future__ import annotations

import re
from io import StringIO
from pathlib import Path
from datetime import datetime
from typing import List, Tuple

import pandas as pd
import plotly.express as px
from rapidfuzz import fuzz

from .config import CACHE_DIR, MAX_ROWS_PREVIEW

# ---------- Paths ----------
TABLE_STORE = (CACHE_DIR / "tables")
TABLE_STORE.mkdir(parents=True, exist_ok=True)

# ---------- Fuzzy tokens ----------
_DATE_CANDIDATE_TOKENS = [
    "date", "day", "invoice date", "posting date", "transaction date",
    "التاريخ", "tarikh", "fecha", "data", "datum",
]
_NET_SALES_TOKENS = [
    "net sales", "net sale", "net revenue", "revenue net", "sales net",
    "sales (net)", "net amount", "amount net", "صافي المبيعات",
    "chiffre d’affaires net", "ingresos netos",
]
_CHANNEL_TOKENS = [
    "cash", "bank", "pos", "card", "visa", "mada", "online", "koinz",
    "jahez", "hunger", "al inma", "alinma", "fodics", "tap", "stripe",
]
_VAT_TOKENS = ["vat", "tax", "15%", "0.15", "ضريبة"]

_MONTH_MAP = {
    "jan": 1, "january": 1, "feb": 2, "february": 2, "mar": 3, "march": 3,
    "apr": 4, "april": 4, "may": 5, "jun": 6, "june": 6, "jul": 7, "july": 7,
    "aug": 8, "august": 8, "sep": 9, "sept": 9, "september": 9, "oct": 10,
    "october": 10, "nov": 11, "november": 11, "dec": 12, "december": 12,
}

# ---------- Small helpers ----------


def _best_match(colnames, targets, min_score=65):
    best_col, best_score = None, -1
    for c in colnames:
        s = str(c)
        for t in targets:
            sc = fuzz.token_set_ratio(s.lower(), t.lower())
            if sc > best_score:
                best_col, best_score = c, sc
    return (best_col if best_score >= min_score else None, best_score)

def _find_numeric_cols(df: pd.DataFrame):
    return [c for c in df.columns if pd.api.types.is_numeric_dtype(df[c])]

def _find_date_col(df: pd.DataFrame) -> str | None:
    cols = list(df.columns)
    c, _ = _best_match(cols, _DATE_CANDIDATE_TOKENS, min_score=60)
    if c is not None:
        return c

    # fallback: column with highest datetime parse rate
    def dt_score(series):
        s = pd.to_datetime(series, errors="coerce")
        return s.notna().mean()

    parse_rates = [(col, dt_score(df[col])) for col in cols]
    parse_rates.sort(key=lambda x: x[1], reverse=True)
    return parse_rates[0][0] if parse_rates and parse_rates[0][1] >= 0.5 else None

def _find_net_sales_col(df: pd.DataFrame) -> str | None:
    num_cols = _find_numeric_cols(df)
    best, best_score = None, -1
    for c in num_cols:
        s = str(c).lower()
        sc = max(fuzz.token_set_ratio(s, t.lower()) for t in _NET_SALES_TOKENS)
        if sc > best_score:
            best, best_score = c, sc
    return best if best_score >= 65 else None

def _derive_net_sales(df: pd.DataFrame) -> pd.Series | None:
    """If there is no single net-sales column, try to sum channels and subtract VAT."""
    num_cols = _find_numeric_cols(df)
    if not num_cols:
        return None
    channel_cols, vat_cols = [], []
    for c in num_cols:
        name = str(c).lower()
        ch_sc = max(fuzz.token_set_ratio(name, t) for t in _CHANNEL_TOKENS)
        vat_sc = max(fuzz.token_set_ratio(name, t) for t in _VAT_TOKENS)
        if ch_sc >= 70 and vat_sc < 60:
            channel_cols.append(c)
        elif vat_sc >= 70:
            vat_cols.append(c)
    if not channel_cols:
        return None
    summed = df[channel_cols].apply(pd.to_numeric, errors="coerce").sum(axis=1)
    if vat_cols:
        summed = summed - df[vat_cols].apply(pd.to_numeric, errors="coerce").sum(axis=1)
    return summed

def _parse_any_range(q: str):
    """Range for averages: Jan 1–30, 2025-01-01..2025-01-30, Jan 15, January."""
    ql = q.lower()
    # ISO..ISO
    m = re.search(r'(\d{4}-\d{2}-\d{2})\s*(?:to|–|—|-|\.{2,})\s*(\d{4}-\d{2}-\d{2})', ql)
    if m:
        a = datetime.fromisoformat(m.group(1)).date()
        b = datetime.fromisoformat(m.group(2)).date()
        if a <= b: return a, b
    # Mon d - d
    m = re.search(r'(' + '|'.join(_MONTH_MAP.keys()) + r')\s*(\d{1,2})\s*(?:to|–|—|-)\s*(\d{1,2})', ql)
    if m:
        mo = _MONTH_MAP[m.group(1)]; d1, d2 = int(m.group(2)), int(m.group(3))
        return datetime(1900, mo, d1).date(), datetime(1900, mo, d2).date()
    # Single day "Jan 15"
    m = re.search(r'(' + '|'.join(_MONTH_MAP.keys()) + r')\s*(\d{1,2})\b', ql)
    if m:
        mo = _MONTH_MAP[m.group(1)]; d = int(m.group(2))
        dt = datetime(1900, mo, d).date()
        return dt, dt
    # Whole month
    m = re.search(r'\b(' + '|'.join(_MONTH_MAP.keys()) + r')\b', ql)
    if m:
        mo = _MONTH_MAP[m.group(1)]
        return datetime(1900, mo, 1).date(), datetime(1900, mo, 31).date()
    return None

def _parse_single_or_range(q: str):
    """For direct lookups/sums: returns ('day', d) or ('range', (a,b)) or None."""
    ql = q.lower()
    m = re.search(r'\b(\d{4}-\d{2}-\d{2})\b', ql)
    if m:
        return ('day', datetime.fromisoformat(m.group(1)).date())
    m = re.search(r'(' + '|'.join(_MONTH_MAP.keys()) + r')\s*(\d{1,2})\b', ql)
    if m:
        mo = _MONTH_MAP[m.group(1)]; d = int(m.group(2))
        return ('day', datetime(1900, mo, d).date())
    m = re.search(r'(\d{4}-\d{2}-\d{2})\s*(?:to|–|—|-|\.{2,})\s*(\d{4}-\d{2}-\d{2})', ql)
    if m:
        a = datetime.fromisoformat(m.group(1)).date()
        b = datetime.fromisoformat(m.group(2)).date()
        if a <= b: return ('range', (a, b))
    m = re.search(r'(' + '|'.join(_MONTH_MAP.keys()) + r')\s*(\d{1,2})\s*(?:to|–|—|-)\s*(\d{1,2})', ql)
    if m:
        mo = _MONTH_MAP[m.group(1)]
        a, b = int(m.group(2)), int(m.group(3))
        return ('range', (datetime(1900, mo, a).date(), datetime(1900, mo, b).date()))
    return None

# ---------- Load full sheets ----------
# app/tools.py
from pathlib import Path
import pandas as pd

# Make sure these are defined at top of tools.py


def _maybe_flatten_columns(df: pd.DataFrame) -> pd.DataFrame:
    if isinstance(df.columns, pd.MultiIndex):
        df = df.copy()
        df.columns = [
            " ".join([str(x) for x in tup if str(x) != "nan"]).strip()
            for tup in df.columns
        ]
    else:
        df = df.rename(columns=lambda c: str(c))
    return df

def load_table_from_meta(meta: dict) -> pd.DataFrame | None:
    p = (meta or {}).get("table_path")
    if not p:
        return None
    try:
        return pd.read_parquet(p)
    except Exception:
        return None

def _score_for_sales(df: pd.DataFrame, meta: dict) -> int:
    cols = [str(c).lower() for c in df.columns]
    has_date = any("date" in c for c in cols)
    has_net  = any(("net" in c and "sale" in c) for c in cols)
    n_days = 0
    if has_date:
        d = pd.to_datetime(df[[c for c in df.columns if "date" in str(c).lower()][0]], errors="coerce").dt.date
        n_days = d.nunique()
    name = f"{meta.get('sheet','')} {meta.get('source','')}".lower()
    sales_hint = 1 if "sales" in name else 0
    return 10*sales_hint + 8*int(has_date and has_net) + min(n_days, 40)

def load_full_tables_from_hits(hits) -> list[tuple[pd.DataFrame, dict]]:
    tables: list[tuple[pd.DataFrame, dict]] = []
    hit_sources = []

    # 1) Use pointers from hits if present
    for text, meta, _ in hits:
        meta = meta or {}
        if meta.get("source"):
            hit_sources.append(meta["source"])
        df = load_table_from_meta(meta)
        if df is not None and not df.empty:
            df = _maybe_flatten_columns(df)
            tables.append((df, meta))

    # 2) Always augment from TABLE_STORE so we don’t miss SALES sheets
    want_at_least = 5
    seen_paths = {m.get("table_path") for _, m in tables if isinstance(m, dict)}
    if TABLE_STORE.exists():
        extras = []
        for p in TABLE_STORE.glob("*.parquet"):
            # prefer same sources if we have them; otherwise include all
            if hit_sources and not any(Path(s).stem in p.name for s in hit_sources if s):
                continue
            if str(p) in seen_paths:
                continue
            try:
                df = pd.read_parquet(p)
                df = _maybe_flatten_columns(df)
                meta = {
                    "source": (Path(p.name).name.split("__")[0] + ".xlsx"),
                    "sheet": p.stem.split("__")[1] if "__" in p.stem else None,
                    "type": "table",
                    "table_path": str(p),
                }
                extras.append((df, meta))
            except Exception:
                continue

        # If we still have very few tables (e.g., no matching source), broaden to all tables
        if len(tables) + len(extras) < want_at_least:
            for p in TABLE_STORE.glob("*.parquet"):
                if str(p) in seen_paths:
                    continue
                try:
                    df = pd.read_parquet(p)
                    df = _maybe_flatten_columns(df)
                    meta = {
                        "source": (Path(p.name).name.split("__")[0] + ".xlsx"),
                        "sheet": p.stem.split("__")[1] if "__" in p.stem else None,
                        "type": "table",
                        "table_path": str(p),
                    }
                    extras.append((df, meta))
                except Exception:
                    continue

        tables.extend(extras)

    # 3) As a last resort, parse preview CSV from text
    if not tables:
        for text, meta, _ in hits:
            if isinstance(text, str) and "\n" in text:
                lines = text.splitlines()
                for i, ln in enumerate(lines):
                    if ln.startswith("TABLE "):
                        csv = "\n".join(lines[i+1:])
                        try:
                            df = pd.read_csv(pd.io.common.StringIO(csv))
                            df = _maybe_flatten_columns(df)
                            tables.append((df, meta or {}))
                        except Exception:
                            pass
                        break

    # 4) Rank: prefer SALES w/ date+net and many unique days
    tables.sort(key=lambda pair: _score_for_sales(*pair), reverse=True)
    return tables


# ---------- Aggregations ----------
def aggregate(query, tables):
    """
    Compute mean of daily totals if the user asks for avg/average/mean.
    Works if names vary: finds date col & net col, or derives net from channels.
    """
    ql = query.lower()
    if not any(k in ql for k in ("avg", "average", "mean")):
        return None

    # normalize (accept df or (df, meta))
    norm_tables = []
    for item in tables:
        df = item[0] if isinstance(item, tuple) else item
        if df is None or df.empty:
            continue
        norm_tables.append(_maybe_flatten_columns(df))
    if not norm_tables:
        return None

    def score(df):
        dcol = _find_date_col(df)
        ncol = _find_net_sales_col(df)
        days = 0
        if dcol:
            d = pd.to_datetime(df[dcol], errors="coerce").dt.date
            days = d.nunique()
        return (10 if dcol else 0) + (10 if (ncol or _derive_net_sales(df) is not None) else 0) + min(days, 40)

    best = max(norm_tables, key=score)

    date_col = _find_date_col(best)
    net_col  = _find_net_sales_col(best)
    if date_col is None:
        return None

    dates = pd.to_datetime(best[date_col], errors="coerce")
    if net_col is not None:
        net_series = pd.to_numeric(best[net_col], errors="coerce")
    else:
        net_series = _derive_net_sales(best)
        if net_series is None:
            return None

    daily = pd.DataFrame({"date": dates, "net": net_series}).dropna(subset=["date"])
    daily = daily.groupby(daily["date"].dt.date)["net"].sum().reset_index()

    rng = _parse_any_range(ql)
    if rng:
        a, b = rng
        def key(d): return (d.month, d.day)
        daily = daily[(daily["date"].apply(key) >= key(a)) & (daily["date"].apply(key) <= key(b))]

    if daily.empty:
        return None

    mean_val = float(daily["net"].mean())
    label = f"{rng[0]}–{rng[1]}" if rng and rng[0] != rng[1] else (f"{rng[0]}" if rng else "selected period")
    note = f"Computed mean of NET SALES per day for {label}."
    return note, pd.DataFrame({"mean": [mean_val]})

def lookup_net_sales(query, tables):
    """
    Direct lookup/sum for: 'what is net sales on Jan 15' or 'sum net sales Jan 1–30'.
    Skips if user asked for averages (aggregate handles that).
    """
    ql = query.lower()
    if any(k in ql for k in ("avg", "average", "mean")):
        return None

    norm = []
    for item in tables:
        df = item[0] if isinstance(item, tuple) else item
        if df is None or df.empty:
            continue
        norm.append(_maybe_flatten_columns(df))
    if not norm:
        return None

    def score(df):
        dcol = _find_date_col(df)
        ncol = _find_net_sales_col(df)
        days = 0
        if dcol:
            d = pd.to_datetime(df[dcol], errors="coerce").dt.date
            days = d.nunique()
        return (10 if dcol else 0) + (10 if (ncol or _derive_net_sales(df) is not None) else 0) + min(days, 40)

    best = max(norm, key=score)
    dcol = _find_date_col(best)
    ncol = _find_net_sales_col(best)
    if dcol is None:
        return None

    dates = pd.to_datetime(best[dcol], errors="coerce")
    if ncol is not None:
        net = pd.to_numeric(best[ncol], errors="coerce")
    else:
        net = _derive_net_sales(best)
        if net is None:
            return None

    daily = (
        pd.DataFrame({"date": dates, "net": net})
        .dropna(subset=["date"])
        .groupby(pd.to_datetime(dates, errors="coerce").dt.date)["net"]
        .sum()
        .reset_index()
    )

    spec = _parse_single_or_range(ql)
    if not spec:
        return None

    if spec[0] == "day":
        d = spec[1]
        row = daily[(daily["date"].apply(lambda x: (x.month, x.day)) == (d.month, d.day))]
        if row.empty:
            return ("No NET SALES found for that day.", pd.DataFrame({"value": [float('nan')]}))
        val = float(row["net"].iloc[0])
        return (f"NET SALES on {d}:", pd.DataFrame({"value": [val]}))

    a, b = spec[1]
    def key(x): return (x.month, x.day)
    select = daily[(daily["date"].apply(key) >= key(a)) & (daily["date"].apply(key) <= key(b))]
    if select.empty:
        return ("No NET SALES found in that range.", pd.DataFrame({"sum": [float('nan')]}))
    return (f"Sum of NET SALES for {a}–{b}:", pd.DataFrame({"sum": [float(select['net'].sum())]}))

# ---------- Charting ----------
def to_chart(query, tables):
    """
    Build a simple chart; returns an HTML string (for Streamlit components.html).
    Prefers DATE × NET (or derived) with aggregation to daily totals.
    """
    q = (query or "").lower()
    if   "pie" in q:                    kind = "pie"
    elif "bar" in q or "column" in q:   kind = "bar"
    else:                               kind = "line"

    norm = []
    for item in tables:
        df = item[0] if isinstance(item, tuple) else item
        if df is None or df.empty:
            continue
        norm.append(_maybe_flatten_columns(df))
    if not norm:
        return None

    def score(df):
        dcol = _find_date_col(df)
        ncol = _find_net_sales_col(df)
        days = 0
        if dcol:
            d = pd.to_datetime(df[dcol], errors="coerce").dt.date
            days = d.nunique()
        return (10 if dcol else 0) + (10 if (ncol or _derive_net_sales(df) is not None) else 0) + min(days, 40)

    best = max(norm, key=score)
    dcol = _find_date_col(best)
    ncol = _find_net_sales_col(best)
    df_plot = best.copy()

    if dcol is not None:
        x = pd.to_datetime(df_plot[dcol], errors="coerce")
        if ncol is not None:
            y = pd.to_numeric(df_plot[ncol], errors="coerce")
        else:
            derived = _derive_net_sales(df_plot)
            if derived is None:
                num_cols = [c for c in df_plot.columns if pd.api.types.is_numeric_dtype(df_plot[c])]
                if not num_cols:
                    return None
                y = pd.to_numeric(df_plot[num_cols[0]], errors="coerce")
            else:
                y = pd.to_numeric(derived, errors="coerce")

        plot_df = pd.DataFrame({"x": x, "y": y}).dropna()
        if plot_df.empty:
            return None

        # aggregate to daily totals if needed
        if plot_df["x"].dt.date.duplicated().any():
            # make an explicit day column, group, then restore an 'x' datetime column
            plot_df["day"] = plot_df["x"].dt.date
            plot_df = plot_df.groupby("day", as_index=False)["y"].sum()
            plot_df["x"] = pd.to_datetime(plot_df["day"])
            plot_df = plot_df.drop(columns=["day"])

        plot_df = plot_df.sort_values("x").head(MAX_ROWS_PREVIEW)

        fig = (
            px.line(plot_df, x="x", y="y") if kind == "line" else
            px.bar(plot_df,  x="x", y="y") if kind == "bar"  else
            px.pie(plot_df, names="x", values="y")
        )
    else:
        # No date column: fallback to first col (x) + first numeric (y)
        cols = list(df_plot.columns)
        if not cols:
            return None
        xcol = cols[0]
        num_cols = [c for c in df_plot.columns if pd.api.types.is_numeric_dtype(df_plot[c])]
        if not num_cols:
            return None
        ycol = num_cols[0]
        d = df_plot[[xcol, ycol]].dropna().head(MAX_ROWS_PREVIEW)
        if d.empty:
            return None
        fig = (
            px.line(d, x=xcol, y=ycol) if kind == "line" else
            px.bar(d,  x=xcol, y=ycol) if kind == "bar"  else
            px.pie(d, names=xcol, values=ycol)
        )

    # IMPORTANT: return a text HTML string (for Streamlit components.html)
    return fig.to_html(full_html=False)
