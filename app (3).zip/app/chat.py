# app/chat.py
from __future__ import annotations

import re
from typing import Dict, Any, List, Tuple

from .retriever import hybrid_retrieve, citations
from .llm import chat_llm
from .tools import (
    aggregate,
    to_chart,
    load_full_tables_from_hits,
    lookup_net_sales,
)

def _collect_tables(retrieved: List[Tuple[str, dict, float]]):
    """
    Prefer loading full sheets (Parquet) via metadata pointers written at ingest time.
    Falls back to cached tables or preview CSV.
    Returns a list of (df, meta).
    """
    return load_full_tables_from_hits(retrieved)

def answer_query(query: str) -> Dict[str, Any]:
    hits = hybrid_retrieve(query)
    if not hits:
        return {"text": "I don't know (no evidence).", "confidence": 0.0, "citations": ""}

    cits = citations(hits)
    conf = sum(s for *_, s in hits) / max(len(hits), 1)

    # === Load full tables for numeric work ===
    tabs = _collect_tables(hits)
    # app/chat.py (inside answer_query after tabs=...)
    try:
        jan_days = set()
        for item in tabs:
            df, meta = item if isinstance(item, tuple) else (item, {})
            if df is None or df.empty:
                continue
            dcol = next((c for c in df.columns if "date" in str(c).lower()), None)
            if dcol is None:
                continue
            d = pd.to_datetime(df[dcol], errors="coerce")
            jan_days |= set(d[d.dt.month == 1].dt.day.dropna().astype(int).tolist())
        print("DEBUG January unique days loaded:", sorted(jan_days))
    except Exception as e:
        print("DEBUG day scan error:", e)

    # 0) Exact day / range sum lookups first
    looked = lookup_net_sales(query, tabs)
    if looked is not None:
        note, df = looked
        res = {
            "text": f"{note}\n\n```\n{df.to_string(index=False)}\n```\n\nSources: {cits}",
            "confidence": conf,
            "citations": cits,
        }
        chart = to_chart(query, tabs)
        if chart:
            res["chart_html"] = chart  # chart is HTML string
        return res

    # 1) Average / mean path
    agg = aggregate(query, tabs)
    if agg is not None:
        note, df = agg
        res = {
            "text": f"{note}\n\n```\n{df.to_string(index=False)}\n```\n\nSources: {cits}",
            "confidence": conf,
            "citations": cits,
        }
        chart = to_chart(query, tabs)
        if chart:
            res["chart_html"] = chart  # HTML string
        return res

    # 2) Try chart generation for generic requests
    chart = to_chart(query, tabs)

    # 3) Fall back to LLM answer grounded in retrieved text
    ctx = []
    for i, (t, m, _) in enumerate(hits, 1):
        ctx.append(f"[Source {i}: {m.get('source','?')}]\\n{t}")
    prompt = f"Question: {query}\n\nUse ONLY these sources.\n\n" + "\n\n".join(ctx)
    out = chat_llm([{"role": "user", "content": prompt}])
    out = re.sub(r"\n{3,}", "\n\n", out).strip()

    res = {
        "text": f"{out}\n\nSources: {cits}",
        "confidence": conf,
        "citations": cits,
    }
    if chart:
        res["chart_html"] = chart  # HTML string
    return res
