import re, uuid
from pathlib import Path
import pandas as pd
from pypdf import PdfReader
import pdfplumber
import docx
from sentence_transformers import SentenceTransformer
import chromadb
from chromadb.config import Settings
# If you use absolute imports elsewhere, keep this:
from app.config import (
    DOCS_DIR, CACHE_DIR, CHUNK_SIZE, CHUNK_OVERLAP, EMBEDDING_MODEL
)

SUPPORTED_EXT = {".txt", ".pdf", ".docx", ".csv", ".xlsx", ".xls"}
TABLE_STORE = CACHE_DIR / "tables"
TABLE_STORE.mkdir(parents=True, exist_ok=True)
# ---------- Parsers ----------

def read_txt(p: Path) -> str:
    return p.read_text(encoding="utf-8", errors="ignore")

def read_pdf_text(p: Path) -> str:
    out = []
    with open(p, "rb") as f:
        r = PdfReader(f)
        for pg in r.pages:
            try:
                out.append(pg.extract_text() or "")
            except Exception:
                out.append("")
    return "\n".join(out)

def read_pdf_tables(p: Path):
    tabs = []
    try:
        with pdfplumber.open(str(p)) as pdf:
            for page_i, page in enumerate(pdf.pages):
                for t in (page.extract_tables() or []):
                    df = pd.DataFrame(t)
                    if df.shape[0] > 1:
                        df.columns = df.iloc[0]
                        df = df[1:]
                    # keep interface consistent: (df, sheet_name_or_None)
                    tabs.append((df, None))
    except Exception:
        pass
    return tabs

def read_excel_sheets(p: Path):
    """Yield (sheet_name, df) for every sheet in the workbook."""
    try:
        xls = pd.ExcelFile(p)
        for name in xls.sheet_names:
            try:
                df = pd.read_excel(xls, sheet_name=name)
                yield name, df
            except Exception:
                # skip unreadable sheets but keep going
                continue
    except Exception:
        return

def read_docx(p: Path) -> str:
    d = docx.Document(str(p))
    return "\n".join(par.text for par in d.paragraphs)

# ---------- Chunking ----------

def chunk_text(text: str, size=CHUNK_SIZE, overlap=CHUNK_OVERLAP):
    text = re.sub(r"\s+", " ", text).strip()
    res = []
    i = 0
    while i < len(text):
        j = min(i + size, len(text))
        res.append(text[i:j])
        if j >= len(text):
            break
        i = max(0, j - overlap)
    return [c for c in res if c]

# ---------- Chroma helpers ----------

def get_client():
    # keep allow_reset=True consistent with retriever
    return chromadb.PersistentClient(
        path=str(CACHE_DIR),
        settings=Settings(allow_reset=True)
    )

def build_or_get_collection(client, name="local_rag"):
    try:
        return client.get_collection(name)
    except Exception:
        return client.create_collection(name)

# ---------- Ingest ----------

def ingest_docs():
    DOCS_DIR.mkdir(exist_ok=True)
    client = get_client()
    coll = build_or_get_collection(client)
    embedder = SentenceTransformer(EMBEDDING_MODEL)

    existing = set(coll.get()["ids"]) if coll.count() else set()

    for p in sorted(DOCS_DIR.rglob("*")):
        if p.suffix.lower() not in SUPPORTED_EXT:
            continue

        text = ""
        tables = []

        if p.suffix.lower() == ".txt":
            text = read_txt(p)

        elif p.suffix.lower() == ".pdf":
            text = read_pdf_text(p)
            tables = read_pdf_tables(p)

        elif p.suffix.lower() == ".docx":
            text = read_docx(p)

        elif p.suffix.lower() == ".csv":
            df = pd.read_csv(p)
            tables = [(df, None)]
            text = f"CSV {p.name} columns: {', '.join(map(str, df.columns))} (rows={len(df)})"
            # ✅ fixed closing braces/parens
        elif p.suffix.lower() in {".xlsx", ".xls"}:
            sheets = list(read_excel_sheets(p))
            tables = [(df, sheet) for sheet, df in sheets]
            # build a multi-sheet summary string used for text chunks
            parts = []
            for sheet, df in sheets:
                cols = ", ".join(map(str, df.columns))
                parts.append(f"EXCEL {p.name} [sheet={sheet}] columns: {cols} (rows={len(df)})")
            text = "\n".join(parts)

        # --- index text chunks ---
        if text:
            chunks = chunk_text(text)
            ids, docs, metas = [], [], []
            for i, ch in enumerate(chunks):
                cid = f"{p.name}:{i}:{uuid.uuid5(uuid.NAMESPACE_DNS, ch)}"
                if cid in existing:
                    continue
                ids.append(cid)
                docs.append(ch)
                metas.append({"source": p.name, "chunk": i, "type": "text"})
            if docs:
                embs = embedder.encode(docs, normalize_embeddings=True).tolist()
                coll.add(ids=ids, documents=docs, embeddings=embs, metadatas=metas)

        # --- index table previews as separate chunks ---
        for t_i, item in enumerate(tables):
            # item may be (df, sheet) or df depending on your earlier code
            if isinstance(item, tuple):
                df, sheet = item
            else:
                df, sheet = item, None

            # drop empty rows/cols (best-effort)
            try:
                df = df.dropna(how="all").dropna(axis=1, how="all")
            except Exception:
                pass

            # ---------- Clean DF once ----------
            df = df.copy()
            if isinstance(df.columns, pd.MultiIndex):
                df.columns = [
                    " ".join([str(x) for x in tup if str(x) != "nan"]).strip()
                    for tup in df.columns
                ]
            else:
                df.columns = [str(c) for c in df.columns]

            for c in df.columns:
                s = df[c]
                if pd.api.types.is_object_dtype(s):
                    s = s.apply(lambda v: v.decode("utf-8", "ignore") if isinstance(v, (bytes, bytearray)) else v)
                    s = s.astype("string")
                df[c] = s
            df = df.convert_dtypes()

            # ---------- Build the summary + preview (used for retrieval) ----------
            preview_csv = df.head(10).to_csv(index=False)
            cols = ", ".join(map(str, df.columns))
            rows = int(len(df))
            doc_text = (
                f"TABLE {p.name}"
                f"{f' [sheet={sheet}]' if sheet else ''}; "
                f"rows={rows}; cols={cols}\n"
                f"PREVIEW (first 10 rows):\n{preview_csv}"
            )

            # Stable ID (file+sheet+preview hash)
            cid = f"{p.name}{f':{sheet}' if sheet else ''}:table:{t_i}:{uuid.uuid5(uuid.NAMESPACE_DNS, preview_csv)}"
            if cid in existing:
                continue  # already indexed

            # ---------- Persist the FULL sheet once ----------
            safe_sheet = (sheet or "sheet").replace("/", "_")
            table_fname = f"{p.stem}__{safe_sheet}__{t_i}.parquet"
            table_path = TABLE_STORE / table_fname
            df.to_parquet(table_path, engine="pyarrow", index=False)

            # ---------- Add the retrievable summary with pointer metadata ----------
            emb = embedder.encode([doc_text], normalize_embeddings=True).tolist()
            coll.add(
                ids=[cid],
                documents=[doc_text],
                embeddings=emb,
                metadatas=[{
                    "source": p.name,
                    "type": "table",
                    "chunk": int(t_i),
                    **({"sheet": str(sheet)} if sheet else {}),
                    "table_path": str(table_path),  # <- pointer to full data
                    "table_rows": rows,
                    "table_cols": ", ".join(map(str, df.columns)),  # <- string (primitive)
                }],
            )

    print("Ingestion complete.")

if __name__ == "__main__":
    ingest_docs()
