# app/tools.py — CLEAN VERSION

import io, re
from pathlib import Path
import pandas as pd
import plotly.express as px
from .config import MAX_ROWS_PREVIEW, CACHE_DIR

AGG = {"average":"mean","avg":"mean","mean":"mean","sum":"sum","total":"sum",
       "count":"count","min":"min","max":"max"}
HINTS = ["amount","cost","price","value","total","qty","quantity","score"]

TABLE_STORE = CACHE_DIR / "tables"

# -------- header/column helpers --------
def _maybe_flatten_columns(df: pd.DataFrame) -> pd.DataFrame:
    if isinstance(df.columns, pd.MultiIndex):
        df = df.copy()
        df.columns = [" ".join([str(x) for x in tup if str(x) != "nan"]).strip()
                      for tup in df.columns]
    else:
        df = df.rename(columns=lambda c: str(c))
    return df

def _find_col(df: pd.DataFrame, target: str) -> str | None:
    t = target.lower().replace(" ", "")
    for c in df.columns:
        s = str(c).lower().replace(" ", "")
        if t in s: return c
    return None

# -------- load full sheets --------
def load_table_from_meta(meta: dict):
    p = meta.get("table_path")
    if not p: return None
    try: return pd.read_parquet(p)
    except Exception: return None

def _load_all_parquet_tables(filter_sources: list[str] | None) -> list[pd.DataFrame]:
    out = []
    if not TABLE_STORE.exists(): return out
    for p in TABLE_STORE.glob("*.parquet"):
        if filter_sources and not any(Path(s).stem in p.name for s in filter_sources if s):
            continue
        try: out.append(pd.read_parquet(p))
        except Exception: continue
    return out

def load_full_tables_from_hits(hits) -> list[pd.DataFrame]:
    tables, hit_sources = [], []
    for text, meta, _ in hits:
        hit_sources.append(meta.get("source"))
        df = load_table_from_meta(meta)
        if df is not None:
            tables.append(df)
            continue

    if not tables:
        tables = _load_all_parquet_tables(filter_sources=hit_sources)

    # Optional last-resort: parse preview CSV only if still nothing
    if not tables:
        for text, meta, _ in hits:
            if isinstance(text, str) and "\n" in text:
                lines = text.splitlines()
                for i, ln in enumerate(lines):
                    if ln.startswith("TABLE "):
                        csv = "\n".join(lines[i+1:])
                        try:
                            tables.append(pd.read_csv(pd.io.common.StringIO(csv)))
                        except Exception:
                            pass
                        break

    return [_maybe_flatten_columns(df) for df in tables if df is not None and not df.empty]

# -------- query parsing --------
def _parse_jan_range(q: str):
    ql = q.lower()
    if "jan" not in ql: return None
    m = re.search(r"jan(?:uary)?\s*([0-9]{1,2})\s*(?:to|-|–|—)\s*([0-9]{1,2})", ql)
    if m:
        a, b = int(m.group(1)), int(m.group(2))
        if 1 <= a <= 31 and a <= b <= 31: return a, b
    return (1, 31)

# -------- numeric aggregation (uses full sheets) --------
def aggregate(query, tables):
    ql = query.lower()
    if not any(k in ql for k in ("avg","average","mean")): return None
    rng = _parse_jan_range(ql)  # (start_day, end_day) or None

    for df in tables:
        if df is None or df.empty: continue
        date_col = _find_col(df, "date")
        net_col  = _find_col(df, "net sales")
        if not date_col or not net_col: continue

        dates = pd.to_datetime(df[date_col], errors="coerce").ffill()
        net   = pd.to_numeric(df[net_col], errors="coerce")
        daily = pd.DataFrame({"date": dates, "net": net}).groupby("date")["net"].sum().reset_index()

        jan = daily[daily["date"].dt.month == 1] if "jan" in ql else daily
        if rng and "jan" in ql:
            a, b = rng
            jan = jan[(jan["date"].dt.day >= a) & (jan["date"].dt.day <= b)]
        if jan.empty: continue

        avg_value = float(jan["net"].mean())
        label = f"Jan {a}–{b}" if rng and "jan" in ql else "the selected period"
        out = pd.DataFrame({"mean": [avg_value]})
        return (f"Computed mean NET SALES per day for {label} on '{net_col}'.", out)
    return None

# -------- charting --------
def to_chart(query, tables):
    q = query.lower(); kind=None
    if "pie" in q: kind="pie"
    elif "line" in q: kind="line"
    elif "bar" in q or "column" in q: kind="bar"
    if not kind: return None

    for df in tables:
        if df is None or df.empty: continue
        d = _maybe_flatten_columns(df).head(MAX_ROWS_PREVIEW)
        x = d.columns[0]
        nums = [c for c in d.columns if pd.api.types.is_numeric_dtype(d[c])]
        if not nums: continue
        y = nums[0]
        try:
            fig = px.bar(d,x=x,y=y) if kind=='bar' else (px.line(d,x=x,y=y) if kind=='line' else px.pie(d,names=x,values=y))
            buf = io.BytesIO(); fig.write_html(buf); buf.seek(0); return buf
        except Exception: continue
